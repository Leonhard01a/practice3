<?php
$this->ms[$this->item["name"]] = Html::nl2str($this->ms[$this->item["name"]], "������]");
$this->ms[$this->item["name"]] = Html::email2anchor($this->ms[$this->item["email"]], $this->ms[$this->item["name"]], 1);
$this->ms[$this->item["url"]] = Html::url2anchor($this->ms[$this->item["url"]], "Homepage", 0);
$this->ms[$this->item["message"]] = Html::autolink($this->ms[$this->item["message"]], "");

$buffer = "<DL>
<DT>
<HR>
<FONT SIZE=\"-1\">
[" . $this->ms[$this->item["id"]] . "] " . $this->ms[$this->item["date"]] . " " . ((!$this->past) ? $this->ms[$this->item["time"]] . "<A HREF=\"".$_SERVER["PHP_SELF"]."?fileid=" . $this->fileid . "&mode=resform&id=" . $this->ms[$this->item["id"]] . "\">�ԐM</A>" : "") . "<BR>
<B>" . $this->ms[$this->item["name"]] . "</B> " . $this->ms[$this->item["url"]] . "<BR>
</FONT>
<BLOCKQUOTE>
" . $this->ms[$this->item["message"]] . "
</BLOCKQUOTE>
</DT>";

$buffer2 = "</DL>\n";
?>