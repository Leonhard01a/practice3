<?php
$this->ms[$this->item["message"]] = Html::br2nl($this->ms[$this->item["message"]]);
$buffer = "<HTML>
<HEAD>
<TITLE></TITLE>
<LINK REL=STYLESHEET TYPE=\"text/css\" HREF=\"".$this->dir."css.css\">
</HEAD>
<BODY>
<FORM ACTION=\"".$_SERVER["PHP_SELF"]."\" METHOD=POST>
<TABLE BORDER=0>
<TR>
<TD><FONT SIZE=\"-1\">���O</FONT></TD>
<TD><INPUT TYPE=text NAME=name SIZE=30 VALUE=\"" . $this->ms[$this->item["name"]] . "\"></TD>
</TR>
<TR>
<TD><FONT SIZE=\"-1\">mail</FONT></TD>
<TD><INPUT TYPE=text NAME=email SIZE=30 VALUE=\"" . $this->ms[$this->item["email"]] . "\"></TD>
</TR>
<TR>
<TD><FONT SIZE=\"-1\">URL</FONT></TD>
<TD><INPUT TYPE=text NAME=url SIZE=50 VALUE=\"" . $this->ms[$this->item["url"]] . "\"></TD>
</TR>
<TR>
<TD COLSPAN=2><FONT SIZE=\"-1\">���b�Z�[�W</FONT></TD>
</TR>
<TR>
<TD COLSPAN=2><TEXTAREA NAME=message COLS=50 ROWS=5>" . $this->ms[$this->item["message"]] . "</TEXTAREA></TD>
</TR>
<TR>
<TD><FONT SIZE=\"-1\">Pass</FONT></TD>
<TD><INPUT TYPE=password NAME=pass SIZE=10>" . (($this->mode == "modify2") ? "<FONT SIZE=\"-1\">���ύX���鎞�̂݋L���B</FONT>" : "") . "</TD>
</TR>
<TR>
<TD COLSPAN=2><INPUT TYPE=submit VALUE=\"���M\"> <INPUT TYPE=reset VALUE=\"���\"></TD>
</TR>
</TABLE>
<INPUT TYPE=hidden NAME=mode VALUE=\"" . $this->mode . "\">
<INPUT TYPE=hidden NAME=fileid VALUE=\"" . $this->fileid . "\">
" . (($this->mode == "modify2" || $this->mode == "res") ? "<INPUT TYPE=hidden NAME=id VALUE=\"" . $this->ms[$this->item["id"]] . "\">" : "") . "
" . (($this->mode == "modify2") ? "<INPUT TYPE=hidden NAME=reid VALUE=\"" . $this->ms[$this->item["reid"]] . "\">" : "") . "
" . (($this->mode == "modify2") ? "<INPUT TYPE=hidden NAME=pass2 VALUE=\"" . $this->pass . "\">" : "") . "
</FORM>
</BODY>
</HTML>\n";
?>