<?php
$buffer = "";
if((!$this->past && $this->past_no) || $this->page_no) {
	$buffer .= "<HR>";

	if($this->past)
		$buffer .= "<A HREF=\"" . ($this->page_no+1) .".html\">��</A> ";

	if($this->page_no) {
		$buffer .= "<A HREF=\"index.html\">�ŐV</A> ";
	} else {
		$buffer .= "�ŐV ";
	}

	if(!$this->past) {
		for($i = $this->past_no; $i > 0; $i--) {
			if($i == $this->page_no)
				$buffer .= $i . " ";
			else
				$buffer .= "<A HREF=\"" . $i . ".html\">" . $i . "</A> ";
		}
	}

	if($this->past && $this->page_no > 1)
		$buffer .= "<A HREF=\"" . ($this->page_no-1) .".html\">�O</A> ";

}

if(!$this->past) {
$buffer .= "<HR>
<FORM METHOD=POST ACTION=\"".$_SERVER["PHP_SELF"]."\">
<FONT SIZE=\"-1\"><DIV ALIGN=right>�e�L��ID <INPUT TYPE=text NAME=id SIZE=10> ���X�L��ID <INPUT TYPE=text NAME=reid SIZE=10> �p�X���[�h <INPUT TYPE=password NAME=pass SIZE=10> <SELECT NAME=mode><OPTION VALUE=\"modify\" SELECTED>�C��</OPTION><OPTION VALUE=\"delete\">�폜</OPTION></SELECT><INPUT TYPE=submit VALUE=\"��C\"></DIV></FONT>
<INPUT TYPE=hidden NAME=fileid VALUE=\"" . $this->fileid . "\">
</FORM>\n";
}

$buffer .= "<HR>
<DIV ALIGN=right>
<FONT SIZE=\"-1\">
Script: <A HREF=\"http://www1.plala.or.jp/ayatohiroka/\" TARGET=\"_top\">- �V���v���E�C�Y�E�x�X�g -</A>
</FONT>
</DIV>
</BODY>
</HTML>\n";
?>