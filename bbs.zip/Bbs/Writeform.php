<?php

require_once("Bbs/Item.php");

//------�������݃t�H�[���𐶐�����N���X------

//------���ۃN���X------
class WriteformBuilder {

	var $dir;
	var $dir_skin;
	var $ms;
	var $item;
	var $pass;
	var $fileid;
	var $mode;

	function WriteformBuilder($ini) {
		$this->dir      = $ini["dir"];
		$this->dir_skin = $ini["dir_skin"];
		$this->ms       = $ini["ms"];
		$this->item     = $ini["item"];
		$this->pass     = $ini["pass"];
		$this->fileid   = $ini["fileid"];
		$this->mode     = $ini["mode"];
	}

	function _makeForm() {}

	function getResult() {
		return $this->_makeForm();
	}
}

//------HTML�Ő�������N���X------
class HtmlWriteformBuilder extends WriteformBuilder {

	function _makeForm() {
		header("Content-type: text/html;charset=Shift_JIS");
		include($this->dir.$this->dir_skin."form.php");
		return $buffer;
	}

}

//------HDML�Ő�������N���X------
class HdmlWriteformBuilder extends WriteformBuilder {

	function _makeForm() {
		header("Content-type: text/x-hdml;charset=Shift_JIS");
		include($this->dir.$this->dir_skin."ezform.php");
		return $buffer;
	}
}

//------WriteformBuilder���g���N���X------
class WriteformDirector {

	var $builder;

	function WriteformDirector($builder) {
		$this->builder = $builder;
	}

	function construct() {
		return $this->builder->getResult();
	}

}

class FormFactory {

	var $ini;

	function FormFactory($dir, $dir_skin, $item, $fileid, $mode, $ms=array(), $pass=null) {
		$this->ini = array(
				"dir"      => $dir,
				"dir_skin" => $dir_skin,
				"item"     => $item,
				"fileid"   => $fileid,
				"mode"     => $mode,
				"ms"       => $ms,
				"pass"     => $pass
				);
	}

	function _createBuilder() {
		switch(Phone::getBrowser()) {
			case "3":
				return new HdmlWriteFormBuilder($this->ini);
				break;
			default:
				return new HtmlWriteFormBuilder($this->ini);
				break;
		}
	}

	function createForm() {
		return new WriteformDirector($this->_createBuilder());
	}
}

?>
