<?php

require_once("Bbs/Item.php");

class Message {

	var $message;
	var $item;

	function Message($message, $item) {
		$this->message = $message;
		$this->check($item);
	}

	function check($item) {
		$error = "";
		$new = array();

		$item_id = $item->getId();
		$item_name = $item->getName();
		$item_flag = $item->getFlag();
		$item_size = $item->getSize();

		$sfac = &StringsFactory::getInstance();
		$item_it = new HashIterator($item_id);
		while(list($key, $val) = $item_it->next()) {
			$id = $key;
			$name = $item_name[$id];
			$flag = $item_flag[$id];
			$size = $item_size[$id];

			$new[$val] = $sfac->create($id, $name);
			$error .= $new[$val]->setStrings($this->message[$val], $flag, $size);
			$this->message[$val] = $new[$val]->getEncodeStrings();
		}

		if($error) {
			Html::error($error);
		}

	}

	function getMessage() {
		return $this->message;
	}
}

?>
