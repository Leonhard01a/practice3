<?php

require_once("Bbs/Item.php");

class BbsPage {

	var $filename;
	var $page_no;
	var $past_no;
	var $past;

	function addThread() {}
	function output() {
		$fileio = new FileIO($this->filename);
		$fileio->put($this->_makeHtml());
		$fileio->output();
		$fileio->close();
	}
	function _makeHtml() {}
	function getNumberOfThread() {}
}

class BbsMessage {
	var $page_no;

	function makeHtml() {}
}

class BbsFactory {
	function createPage() {}
	function createLeafMessage() {}
	function createCompositeMessage() {}
}


class LightPage extends BbsPage {

	var $dir_skin;
	var $buffer;
	var $not;
	var $fileid;

	function LightPage($dir_skin, $filename, $fileid, $page_no, $past_no, $past) {
		$this->dir_skin = $dir_skin;
		$this->filename = $filename;
		$this->fileid   = $fileid;
		$this->past_no = $past_no;
		$this->page_no = $page_no;
		$this->past    = $past;
		$this->not = 0;
	}

	function addThread($message) {
		$this->not++;
		$this->_makeThread($message);
	}

	function _makeHtml() {
		$buffer  = $this->_makeHead();
		$buffer .= $this->buffer;
		$buffer .= $this->_makeFoot();
		return $buffer;
	}

	function _makeHead() {
		include($this->dir_skin . "head.php");
		return $buffer;
	}

	function _makeFoot() {
		include($this->dir_skin . "foot.php");
		return $buffer;
	}

	function _makeThread($message) {
		$this->buffer .= $message->makeHtml();
	}

	function getNumberOfThread() {
		return $this->not;
	}
}

class LightMessage extends BbsMessage {

	var $ms;
	var $dir_skin;
	var $item;
	var $fileid;
	var $past;

	function LightMessage($ms, $item, $dir_skin, $fileid, $past) {
		$this->ms       = $ms;
		$this->item     = $item;
		$this->dir_skin = $dir_skin;
		$this->fileid   = $fileid;
		$this->past     = $past;
	}
	function getClassname() {}
}

class LightCompositeMessage extends LightMessage {

	var $buffer;
	var $buffer2;

	function makeHtml() {
		include($this->dir_skin . "parent.php");
		return $buffer.$this->buffer.$buffer2;
	}

	function add($message) {
		$this->buffer .= $message->makeHtml();
	}

}

class LightLeafMessage extends LightMessage {

	function makeHtml() {
		include($this->dir_skin . "child.php");
		return $buffer;
	}

}

class LightBbsFactory extends BbsFactory {

	var $dir_skin;
	var $item;
	var $fileid;
	var $filename;
	var $page_no;
	var $past_no;
	var $past;

	function LightBbsFactory($dir_skin, $item, $fileid, $filename, $page_no=0, $past_no=0, $past=0) {
		$this->dir_skin = $dir_skin;
		$this->item     = $item;
		$this->fileid   = $fileid;
		$this->filename = $filename;
		$this->page_no  = $page_no;
		$this->past_no  = $past_no;
		$this->past     = $past;
	}

	function createPage() {
		return new LightPage($this->dir_skin, $this->filename, $this->fileid, $this->page_no, $this->past_no, $this->past);
	}

	function createLeafMessage($message) {
		return new LightLeafMessage($message, $this->item, $this->dir_skin, $this->fileid, $this->past);
	}

	function createCompositeMessage($message) {
		return new LightCompositeMessage($message, $this->item, $this->dir_skin, $this->fileid, $this->past);
	}
}

?>
