<?php

class LogBuilder {

	var $log;
	var $buffer;
	var $buffer2;
	var $head;
	var $file_it;
	var $eot;	//	End Of Thread
	var $not;	//	Number Of Thread

	function LogBuilder($filename) {
		$this->log = new FileIO($filename);
		$this->buffer  = "";
		$this->buffer2 = "";
		$this->head = array();
		$this->eot = "EOT\n";
		$this->not = 0;
	}

	function open() {
		$this->log->open();
		$this->file_it = $this->log->iterator();
		$this->head = explode(",", trim($this->file_it->next()));
	}

	function setHead($i, $buffer) {
		$this->head[$i] = $buffer;
	}

	function getHead($i) {
		return $this->head[$i];
	}

	function _isHead() {
		return implode(",", $this->head) . "\n";
	}

	function output() {
		$this->setHead(NUM, $this->not);
		$this->log->put($this->_isHead() . $this->buffer . $this->buffer2);
		$this->log->output();
	}

	function close() {
		$this->log->close();
	}

	function makeStartThread($buffer, $mode=0) {
		$this->not++;
		$this->put($buffer . "\n", $mode);
	}

	function putMessage($buffer, $mode=0) {
		$this->put($buffer, $mode);
	}

	function makeEndThread($mode=0) {
		$this->put($this->eot, $mode);
	}

	function put($buffer, $mode=0) {
		if(!$mode) 
			$this->buffer  .= $buffer;
		else
			$this->buffer2 .= $buffer;
	}

	function nextThread() {
		return ($this->file_it->hasNext() && ($tmp = trim($this->file_it->next()))) ? $tmp : false;
	}

	function nextMessage() {
		$tmp = $this->file_it->next();
		return ($tmp == $this->eot) ? false : $tmp;
	}

	function getNumberOfThread() {
		return $this->not;
	}
}

?>