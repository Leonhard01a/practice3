<?php

class Item {

	var $item_id;
	var $item_name;
	var $item_flag;
	var $item_size;
	var $item_form;
	var $filename;

	function &getInstance($filename) {
		static $singleton_;
		if ($singleton_ == null) {
			$singleton_ = new Item();
			$singleton_->filename = $filename;
			$singleton_->item_id   = array();
			$singleton_->item_name = array();
			$singleton_->item_flag = array();
			$singleton_->item_size = array();
			$singleton_->item_form = array();
			$singleton_->input();
		}
		return $singleton_;
	}

	function input() {
		$array_id   = array("id",     "reid",         "stamp",          "date", "time", "ip", "host",   "ua");
		$array_name = array("�L��ID", "���X�L��ID",   "�^�C���X�^���v", "���t", "����", "IP", "�z�X�g", "UserAgent");
		$array_flag = array(0,        0,              1,                1,      1,      1,    1,        0);
		$array_size = array(100,      100,            200,            200,    200,    200,  200,      400);

		$file = file($this->filename);
		$file_it = new HashIterator($file);
		while(list($key, $val) = $file_it->next()) {
			list($id, $name, $flag, $size) = explode(",", $val);
			array_push($array_id,   $id);
			array_push($array_name, $name);
			array_push($array_flag, $flag);
			array_push($array_size, $size);
			array_push($this->item_form, $id);
		}

		reset($array_id);
		$it = new HashIterator($array_id);
		while(list($key, $val) = $it->next()) {
			$this->item_id[$val]   = $key;
			$this->item_name[$val] = $array_name[$key];
			$this->item_flag[$val] = $array_flag[$key];
			$this->item_size[$val] = $array_size[$key];
		}
	}

	function getId() {
		return $this->item_id;
	}

	function getName() {
		return $this->item_name;
	}

	function getFlag() {
		return $this->item_flag;
	}

	function getSize() {
		return $this->item_size;
	}

	function getForm() {
		return $this->item_form;
	}
}

?>
