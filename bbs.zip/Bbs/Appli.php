<?php

require_once("Bbs/Item.php");
require_once("Bbs/Message.php");
require_once("Bbs/Bbs.php");
require_once("Bbs/Log.php");
require_once("Bbs/Writeform.php");

define("NO", 0);
define("RENO", 1);
define("PASTNO", 2);
define("NUM", 3);
define("CHECK", 4);

class BbsAppli {

	var $administ;
	var $dir;
	var $logmax;
	var $file_html;
	var $file_log;
	var $file_item;
	var $dir_skin;
	var $fileid;
	var $dir_past;
	var $mailini;

	function BbsAppli($ini, $mailini) {
		$it = new HashIterator($ini);
		while(list($key, $val) = $it->next()) {
			$this->$key = $val;
		}
		$this->mailini = $mailini;
	}

	function _extract($id, $reid) {
		$flag_extract = false;
		$message = array();

		$item = $this->_getItemId();
		$log = $this->_setLogBuilder();
		$log->open();
		while(($no = $log->nextThread()) && !$flag_extract) {
			while(($tmp = $log->nextMessage()) && !$flag_extract) {
				$message = explode(",", $tmp);
				if($id == $no && $reid == $message[$item["reid"]])
					$flag_extract = true;
			}
		}
		$log->close();
		if(!$flag_extract) {
			Html::error("�L����������܂���B<BR>\n");
		}
		return $message;
	}

	function _view_form($mode, $ms=array(), $pass=null) {
		$item = $this->_getItemId();
		$factory = new FormFactory($this->dir, $this->dir_skin, $item, $this->fileid, $mode, $ms, $pass);
		$form = $factory->createForm();
		echo $form->construct();
	}

	function _newMessage() {
		$item = &Item::getInstance($this->dir . $this->file_item);
		$form = $item->getForm();

		$dt = new DateTime();
		$ip = $_SERVER["REMOTE_ADDR"];
		$message = array(
				"",
				"",
				$dt->getStamp(),
				$dt->getDate(),
				$dt->getTime(),
				$ip,
				gethostbyaddr($ip),
				$_SERVER["HTTP_USER_AGENT"]
				);

		$form_it = new HashIterator($form);
		while(list($key, $val) = $form_it->next()) {
			array_push($message, $_POST[$val]);
		}

		$new_message = new Message($message, $item);
		return $new_message->getMessage();
	}

	function _ms2log($message) {
		return implode(",", $message) . ",\n";
	}

	function _getItemId() {
		$item = &Item::getInstance($this->dir . $this->file_item);
		return $item->getId();
	}

	function _setBbsFactory($file_html, $page_no=0, $past_no=0, $past=0) {
		$item = $this->_getItemId();
		return new LightBbsFactory($this->dir.$this->dir_skin, $item, $this->fileid, $file_html, $page_no, $past_no, $past);
	}

	function _setLogBuilder() {
		return new LogBuilder($this->dir.$this->file_log);
	}

	function _makeBbs(&$log) {
		$log->open();
		$past_no = $log->getHead(PASTNO) + (($log->getHead(NUM) > $this->logmax) ? 1 : 0);

		$this->_makePage($log, $this->dir.$this->dir_past.$this->file_html, 0, $past_no, 0, $this->logmax);
		$this->_makePage($log, $this->dir.$this->dir_past.($log->getHead(PASTNO)+1).".html", $log->getHead(PASTNO)+1, $past_no, 0, 0);

		$log->close();
	}

	function _makePage(&$log, $filename, $page_no=0, $past_no=0, $past=0, $logmax) {
		$factory = $this->_setBbsFactory($filename, $page_no, $past_no, $past);
		$page = $factory->createPage();
		while((!$logmax || ($page->getNumberOfThread() < $this->logmax)) && $log->nextThread()) {
			$message = $factory->createCompositeMessage(explode(",", $log->nextMessage()));
			while($tmp = $log->nextMessage()) {
				$message->add($factory->createLeafMessage(explode(",", $tmp)));
			}
			$page->addThread($message);
		}
		$page->output();
	}

	function _checkDouble(&$log, &$ms) {
		$ite  = &Item::getInstance($this->dir . $this->file_item);
		$form = $ite->getForm();
		$item = $ite->getId();
		$check = "";

		$it = new HashIterator($form);
		while(list($key, $val) = $it->next()) {
			$check .= $ms[$item[$val]] . "<>";
		}

		if($log->getHead(CHECK) == $check)
			Html::error("��d���M�ł��B<BR>\n");
		else
			$log->setHead(CHECK, $check);

	}

	function _sendMail($message, $item, $mode=null) {
		if(!$this->mailini["to"] || ($this->administ == $message[$item["name"]])) return;
		$body  = $mode
		      .  "���M�� : " . $message[$item["name"]]    . "\n"
		      .  "���e�@ : " . $message[$item["message"]] . "\n";
		$body = Html::br2nl($body);
		if(strlen($body) > $this->mailini["mailmax"])
			$body = substr($body, 0, $this->mailini["mailmax"]-2) . "..";

		$mail = new Mail();
		$mail->set($this->mailini["to"], $this->fileid, $body, $this->mailini["from"]);
		$mail->send();
	}

	function write_screen() {
		$this->_view_form("write");
	}

	function res_screen($id) {
		$this->_view_form("res", array($id));
	}

	function modify_screen($id, $reid, $pass, $flag=false) {
		$item = $this->_getItemId();
		$message = $this->_extract($id, $reid);

		if(md5($pass) == $message[$item["pass"]])
			$flag = true;
		if(!$flag)
			Html::error("�p�X���[�h���Ⴂ�܂��B<BR>\n");

		$this->_view_form("modify2", $message, $pass);
	}

	function add() {
		$flag_past = false;
		$item = $this->_getItemId();
		$new_message = $this->_newMessage();

		$log = $this->_setLogBuilder();
		$log->open();
		$this->_checkDouble($log, $new_message);
		$log->setHead(NO, $log->getHead(NO)+1);
		if($log->getHead(NUM) >= 2*$this->logmax) {
			$flag_past = true;
			$log->setHead(PASTNO, $log->getHead(PASTNO)+1);
		}
		$new_message[$item["id"]] = $log->getHead(NO);

		$log->makeStartThread($log->getHead(NO));
		$log->putMessage($this->_ms2log($new_message));
		$log->makeEndThread();
		while((!$flag_past || ($flag_past && $log->getNumberOfThread() <= $this->logmax)) && $no = $log->nextThread()) {
			$log->makeStartThread($no);
			while($tmp = $log->nextMessage()) {
				$log->putMessage($tmp);
			}
			$log->makeEndThread();
		}
		if($flag_past)
			$this->_makePage($log, $this->dir.$this->dir_past.$log->getHead(PASTNO).".html", $log->getHead(PASTNO), $log->getHead(PASTNO), 1, 0);
		$log->output();
		$log->close();
		$this->_makeBbs($log);
		$this->_sendMail($new_message, $item, "�V�K\n");
	}

	function addChild($id) {
		$flag_parent = false;
		$item = $this->_getItemId();
		$new_message = $this->_newMessage();

		$log = $this->_setLogBuilder();
		$log->open();
		$this->_checkDouble($log, $new_message);
		$log->setHead(RENO, $log->getHead(RENO)+1);
		$new_message[$item["id"]] = $id;
		$new_message[$item["reid"]] = $log->getHead(RENO);
		while($no = $log->nextThread()) {
			$flag = ($id == $no) ? 0 : 1;
			$log->makeStartThread($no, $flag);
			while($tmp = $log->nextMessage()) {
				$log->putMessage($tmp, $flag);
			}
			if(!$flag) {
				$log->putMessage($this->_ms2log($new_message), $flag);
				$flag_parent = true;
			}
			$log->makeEndThread($flag);
		}
		if(!$flag_parent) {
			Html::error("�L����������܂���B<BR>\n");
		}
		$log->output();
		$log->close();
		$this->_makeBbs($log);
		$this->_sendMail($new_message, $item, "���X\n");
	}

	function modify($id, $reid, $pass, $flag=false) {
		$item = $this->_getItemId();

		$new_message = $this->_newMessage();
		$new_message[$item["id"]] = $id;
		$new_message[$item["reid"]] = $reid;

		$log = $this->_setLogBuilder();
		$log->open();
		while($no = $log->nextThread()) {
			$log->makeStartThread($no);
			while($tmp = $log->nextMessage()) {
				$message = explode(",", $tmp);
				if($id == $message[$item["id"]] && $reid == $message[$item["reid"]]) {
					if(md5($pass) == $message[$item["pass"]]) {
						$flag = true;
					}
					$new_message[$item["stamp"]] = $message[$item["stamp"]];
					$new_message[$item["date"]]  = $message[$item["date"]];
					$new_message[$item["time"]]  = $message[$item["time"]];
					$new_message[$item["ip"]]    = $message[$item["ip"]];
					$new_message[$item["host"]]  = $message[$item["host"]];
					$new_message[$item["ua"]]    = $message[$item["ua"]];
					$new_message[$item["pass"]]  = (md5(null) == $new_message[$item["pass"]]) ? $message[$item["pass"]] : $new_message[$item["pass"]];
					$tmp = $this->_ms2log($new_message);
				}
				$log->putMessage($tmp);
			}
			$log->makeEndThread();
		}
		if(!$flag)
			Html::error("�p�X���[�h���Ⴂ�܂��B<BR>\n");
		$log->output();
		$log->close();
		$this->_makeBbs($log);
	}

	function delete($id, $reid, $pass, $flag=false) {
		$item = $this->_getItemId();

		$log = $this->_setLogBuilder();
		$log->open();
		while($no = $log->nextThread()) {
			if(!$reid && $no == $id) {
				$message = explode(",", $log->nextMessage());
				if(md5($pass) == $message[$item["pass"]]) {
					$flag = true;
				}
				while($tmp = $log->nextMessage()) {}
			} else {
				$log->makeStartThread($no);
				while($tmp = $log->nextMessage()) {
					$message = explode(",", $tmp);
					if($id == $no && $reid == $message[$item["reid"]]) {
						if(md5($pass) == $message[$item["pass"]]) {
							$flag = true;
						}
					} else {
						$log->putMessage($tmp);
					}
				}
				$log->makeEndThread();
			}
		}
		if(!$flag)
			Html::error("�p�X���[�h���Ⴂ�܂��B<BR>\n");
		$log->output();
		$log->close();
		$this->_makeBbs($log);
	}
}
?>
