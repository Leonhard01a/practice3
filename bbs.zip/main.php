<?php

require_once("Module/DateTime.php");
require_once("Module/Html.php");
require_once("Module/IO.php");
require_once("Module/Iterator.php");
require_once("Module/Lock.php");
require_once("Module/Mail.php");
require_once("Module/Strings.php");
require_once("Module/Phone.php");

require_once("custom.php");
require_once("Bbs/Appli.php");

$array = array("mode", "id", "reid", "pass", "pass2", "fileid");
$it = new HashIterator($array);
while(list($key, $val) = $it->next()) {
	$$val = ($_GET[$val]) ? $_GET[$val] : $_POST[$val];
}

if(!$dir[$fileid]) {
	Html::error("�s���ȃt�@�C��ID�ł��B");
}

$ini = array(
		"administ"  => $administ,
		"dir"       => $dir[$fileid],
		"logmax"    => $logmax[$fileid],
		"file_html" => $file_html,
		"file_log"  => $file_log,
		"file_item" => $file_item,
		"dir_skin"  => $dir_skin,
		"fileid"    => $fileid,
		"dir_past"  => $dir_past
	);

$mailini = array(
		"to" => $to[$fileid],
		"from" => $from,
		"mailmax" => $mailmax
	);

$html = $path.$ini["dir"].$ini["dir_past"].$ini["file_html"];

//------���C������------
$lock = new Lock($dir_lock.$ini["fileid"].".txt");
if($lock->open()) {
$appli = _setBbsAppli($ini, $mailini);
switch($mode) {
	case "write":
		$appli->add();
		_location($html);
		break;
	case "res":
		$appli->addChild($id);
		_location($html);
		break;
	case "modify":
		$appli->modify_screen($id, $reid, $pass, _checkPass($password, $pass));
		break;
	case "modify2":
		$appli->modify($id, $reid, $pass2, _checkPass($password, $pass2));
		_location($html);
		break;
	case "delete":
		$appli->delete($id, $reid, $pass, _checkPass($password, $pass));
		_location($html);
		break;
	case "resform":
		$appli->res_screen($id);
		break;
	default:
		$appli->write_screen();
		break;
}
$lock->close();
} else {
	Html::error("�t�@�C���̃��b�N�Ɏ��s���܂���<BR>\n");
}

function _setBbsAppli($ini, $mailini=array()) {
	return new BbsAppli($ini, $mailini);
}

function _location($html) {
	header("Location: ".$html);
}

function _checkPass($pass, $pass2) {
	return ($pass == $pass2) ? true : false;
}
?>
