<?php

class DateTime {

	var $stamp;
	var $date;
	var $time;

	function DateTime() {
		$this->input();
	}

	function input() {
		$this->stamp = time() + 60*60*9;
		$this->date  = gmdate("y/m/d(D)", $this->stamp);
		$this->time  = gmdate("H:i:s",    $this->stamp);
	}

	function getStamp() {
		return $this->stamp;
	}

	function getDate() {
		return $this->date;
	}

	function getTime() {
		return $this->time;
	}
}

?>
