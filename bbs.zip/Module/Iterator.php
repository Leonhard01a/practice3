<?php

class HashIterator {

	var $array;

	function HashIterator(&$array) {
		$this->array = &$array;
	}

	function next() {
		return each($this->array);
	}
}

?>
