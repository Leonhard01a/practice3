<?php

class Lock {

	var $filename;
	var $fp;

	function Lock($filename) {
		$this->filename = $filename;
	}

	function open() {
		$this->fp = fopen($this->filename, "w");
		return (flock($this->fp, LOCK_EX)) ? true : false;
//		return true;
	}

	function close() {
		fclose($this->fp);
	}
}

?>
