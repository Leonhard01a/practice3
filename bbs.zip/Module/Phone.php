<?php

define("PC",    0);
define("IMODE", 1);
define("JSKY",  2);
define("EZWEB", 3);
define("H",     4);

class Phone {
	function getBrowser() {
		$ua = $_SERVER["HTTP_USER_AGENT"];
		if(ereg("^DoCoMo/", $ua))
			return IMODE;
		else if(ereg("^J-SKY/", $ua))
			return JSKY;
		else if(ereg("^UP\.Browser/", $ua))
			return EZWEB;
		else if(ereg("^PDXGW/", $ua))
			return H;
		else
			return PC;
	}
}

?>