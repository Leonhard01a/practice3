<?php

class IO {
	function open() {}
	function get() {}
	function put() {}
	function output() {}
	function close() {}
	function iterator() {}
}

class IOIterator {
	function hasNext() {}
	function next() {}
}

class FileIO extends IO {

	var $filename;
	var $fp;
	var $buffer;

	function FileIO($filename) {
		$this->buffer = "";
		$this->filename = $filename;
		$this->open();
	}

	function open() {
		if(!$this->fp = @fopen($this->filename, "r+"))
			$this->fp = fopen($this->filename, "w");
	}

	function get() {
		return fgets($this->fp, 10240);
	}

	function put($buffer) {
		$this->buffer .= $buffer;
	}

	function output() {
		rewind($this->fp);
		fputs($this->fp, $this->buffer);
		ftruncate($this->fp, ftell($this->fp));
	}

	function close() {
		fclose($this->fp);
	}

	function iterator() {
		return new FileIterator($this);
	}

	function eof() {
		return (feof($this->fp)) ? false : true;
	}
}

class FileIterator extends IOIterator {

	var $fileio;

	function FileIterator(&$fileio) {
		$this->fileio = &$fileio;
	}

	function hasNext() {
		return $this->fileio->eof();
	}

	function next() {
		return $this->fileio->get();
	}
}
?>
